# Running PROJECT PHANTOM

This is a static HTML/CSS/JavaScript game using Three.js. Keep the existing folder structure; no build step, package installation, backend, or secrets are required.

Use Replit's **Run** button to start the **Start application** workflow:

```sh
python3 -m http.server 5000 --bind 0.0.0.0
```

Open the web preview, preferably in a separate browser tab. On a phone, use landscape orientation. Move with the left joystick, drag the right side to look, and use the labeled action buttons. Desktop movement supports WASD/arrow keys, Space to jump, R to reload, and Escape to pause.

Internet access is required to load Three.js 0.170.0 from jsDelivr. The browser must support WebGL. HUD layout preferences are saved locally in the browser; this is a local training prototype, not online multiplayer.
