export class HUD {
  constructor() {
    this.healthFill=document.querySelector('#health-fill');
    this.shieldFill=document.querySelector('#shield-fill');
    this.healthText=document.querySelector('#health-text');
    this.shieldText=document.querySelector('#shield-text');
    this.ammoText=document.querySelector('#ammo-text');
    this.aliveText=document.querySelector('#alive-count');
    this.zoneText=document.querySelector('#zone-text');
    this.messageEl=document.querySelector('#message');
  }
  health(health,shield=25) {
    const h=Math.max(0,Math.min(100,health));
    this.healthFill.style.width=h+'%'; this.healthText.textContent=Math.ceil(h);
    this.shieldFill.style.width=Math.max(0,Math.min(100,shield))+'%'; this.shieldText.textContent=Math.ceil(shield);
  }
  ammo(ammo,reserve) { this.ammoText.textContent=ammo; this.ammoText.nextElementSibling.textContent=' / '+reserve; }
  alive(count) { this.aliveText.textContent=count; }
  zone(text) { this.zoneText.textContent=text; }
  message(text) { this.messageEl.textContent=text; }
}
