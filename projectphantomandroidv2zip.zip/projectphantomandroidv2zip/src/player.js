import * as THREE from 'three';

export class Player {
  constructor(scene) {
    this.scene = scene; this.position = new THREE.Vector3(0, 0, 8);
    this.velocityY = 0; this.health = 100; this.grounded = true; this.jumpHeld = false;
    this.yaw = 0; this.pitch = -.08; this.speed = 10; this.slideTimer = 0; this.walkClock = 0;
    this.group = new THREE.Group(); this.group.position.copy(this.position);
    const mat = (color, roughness=.7, metalness=0) => new THREE.MeshStandardMaterial({color, roughness, metalness});
    const suit = mat(0x263b4a, .7), armor = mat(0x405866, .5), accent = mat(0xc8f36a, .45);
    const skin = mat(0xb77f5d, .82), dark = mat(0x121d26, .6), metal = mat(0x29343b, .38, .55);
    const make = (geo, material, pos, parent=this.group) => { const m = new THREE.Mesh(geo, material); m.position.set(...pos); m.castShadow = true; m.receiveShadow = true; parent.add(m); return m; };
    // Stylized tactical character built from lightweight geometry so it remains phone-friendly.
    this.torso = make(new THREE.CapsuleGeometry(.43, .68, 5, 10), suit, [0, 1.34, 0]);
    make(new THREE.BoxGeometry(.72,.46,.42), armor, [0,1.48,-.02]);
    make(new THREE.BoxGeometry(.14,.5,.44), accent, [0,1.48,-.25]);
    make(new THREE.SphereGeometry(.29,16,12), skin, [0,2.05,0]);
    make(new THREE.SphereGeometry(.31,16,10,0,Math.PI*2,0,Math.PI*.58), dark, [0,2.15,-.015]);
    make(new THREE.BoxGeometry(.42,.12,.33), accent, [0,2.14,-.06]);
    make(new THREE.BoxGeometry(.52,.62,.25), dark, [0,1.35,.37]);
    make(new THREE.BoxGeometry(.42,.13,.28), accent, [0,1.5,.51]);
    this.legs = []; this.arms = [];
    for (const side of [-1,1]) {
      const leg = make(new THREE.CapsuleGeometry(.16,.48,4,8), dark, [side*.2,.48,0]); this.legs.push(leg);
      make(new THREE.BoxGeometry(.25,.14,.38), metal, [side*.2,.12,-.04]);
      const arm = make(new THREE.CapsuleGeometry(.13,.43,4,8), suit, [side*.48,1.43,-.02]);
      arm.rotation.z = side * -.16; this.arms.push(arm);
      make(new THREE.BoxGeometry(.17,.18,.18), accent, [side*.48,1.16,-.04]);
    }
    // Detailed compact rifle silhouette held in front of the body.
    const rifle = new THREE.Group(); rifle.position.set(.42,1.48,-.44); this.group.add(rifle);
    make(new THREE.BoxGeometry(.16,.15,.9), metal, [0,0,-.2], rifle);
    make(new THREE.BoxGeometry(.2,.09,.34), dark, [0,.1,-.12], rifle);
    make(new THREE.CylinderGeometry(.035,.035,.48,8), metal, [0,0,-.77], rifle).rotation.x = Math.PI/2;
    make(new THREE.BoxGeometry(.12,.24,.16), dark, [0,-.17,.03], rifle);
    make(new THREE.BoxGeometry(.08,.08,.19), accent, [0,.11,-.22], rifle);
    scene.add(this.group);
  }
  rotateCamera(dx,dy) { this.yaw -= dx; this.pitch = THREE.MathUtils.clamp(this.pitch-dy,-.7,.35); }
  jump() { if (this.grounded && this.slideTimer <= 0) { this.velocityY=7.8; this.grounded=false; } }
  slide() { if (this.grounded && this.slideTimer <= 0) this.slideTimer = .72; }
  update(dt, input) {
    const forward=input.forward||0, side=input.side||0, moveLen=Math.hypot(forward,side);
    const fx=-Math.sin(this.yaw), fz=-Math.cos(this.yaw), rx=Math.cos(this.yaw), rz=-Math.sin(this.yaw);
    let vx=fx*forward+rx*side, vz=fz*forward+rz*side;
    if(moveLen>1){vx/=moveLen;vz/=moveLen;}
    let speed = this.speed;
    if (this.slideTimer > 0) { speed *= 1.75; this.slideTimer = Math.max(0, this.slideTimer-dt); this.group.scale.y = .68; }
    else this.group.scale.y += (1-this.group.scale.y)*Math.min(1,dt*10);
    this.position.x+=vx*speed*dt; this.position.z+=vz*speed*dt;
    this.position.x=THREE.MathUtils.clamp(this.position.x,-88,88); this.position.z=THREE.MathUtils.clamp(this.position.z,-88,88);
    this.velocityY-=19*dt; this.position.y+=this.velocityY*dt;
    if(this.position.y<=0){this.position.y=0;this.velocityY=0;this.grounded=true;}
    this.group.position.copy(this.position);
    if(moveLen>.08){this.group.rotation.y=Math.atan2(-vx,-vz); this.walkClock+=dt*10; this.legs.forEach((l,i)=>l.rotation.x=Math.sin(this.walkClock+i*Math.PI)*.45); this.arms.forEach((a,i)=>a.rotation.x=Math.sin(this.walkClock+i*Math.PI)*.08);}
    else { this.legs.forEach(l=>l.rotation.x*=.8); this.arms.forEach(a=>a.rotation.x*=.8); }
  }
  updateCamera(camera) {
    const target=new THREE.Vector3(this.position.x,this.position.y+(this.slideTimer>0?1.0:1.58),this.position.z);
    const distance=6.0, horizontal=this.yaw;
    const offset=new THREE.Vector3(Math.sin(horizontal)*distance,2.35+this.pitch*2,Math.cos(horizontal)*distance);
    camera.position.lerp(target.clone().add(offset),.18);
    camera.lookAt(target.clone().add(new THREE.Vector3(-Math.sin(horizontal)*4,this.pitch*4,-Math.cos(horizontal)*4)));
  }
}
