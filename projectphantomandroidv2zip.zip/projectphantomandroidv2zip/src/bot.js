import * as THREE from 'three';

export class Bot {
  constructor(scene, position, id) {
    this.scene=scene; this.position=position.clone(); this.id=id; this.health=100; this.alive=true; this.timer=Math.random()*2;
    this.group=new THREE.Group(); this.group.position.copy(this.position);
    const mat=new THREE.MeshStandardMaterial({color:[0xb44e48,0x6c68b8,0xc17a38,0x3d8d86,0x9a4e8e][id%5],roughness:.8});
    const body=new THREE.Mesh(new THREE.CapsuleGeometry(.42,.72,4,7),mat); body.position.y=1.25; this.group.add(body);
    const head=new THREE.Mesh(new THREE.SphereGeometry(.28,9,7),new THREE.MeshStandardMaterial({color:0xb98a6b})); head.position.y=2; this.group.add(head);
    const hpBase=new THREE.Mesh(new THREE.BoxGeometry(1.1,.09,.08),new THREE.MeshBasicMaterial({color:0x27383d})); hpBase.position.set(0,2.55,0); this.group.add(hpBase);
    this.hpFill=new THREE.Mesh(new THREE.BoxGeometry(1,.07,.09),new THREE.MeshBasicMaterial({color:0x9cf06a})); this.hpFill.position.set(0,2.55,-.05); this.group.add(this.hpFill);
    this.group.traverse(o=>{if(o.isMesh){o.userData.bot=this; o.castShadow=false;}});
    this.mesh=body; scene.add(this.group);
  }
  takeDamage(amount) {
    if(!this.alive)return;
    this.health=Math.max(0,this.health-amount);
    this.hpFill.scale.x=Math.max(.001,this.health/100);
    if(this.health<=0){this.alive=false;this.scene.remove(this.group);}
  }
  update(dt, playerPosition) {
    if(!this.alive)return;
    this.timer-=dt;
    const toPlayer=playerPosition.clone().sub(this.position);
    const dist=toPlayer.length();
    if(dist<27 && dist>5){
      toPlayer.y=0;toPlayer.normalize();
      this.position.addScaledVector(toPlayer,dt*(1.7+(this.id%3)*.25));
      this.group.rotation.y=Math.atan2(-toPlayer.x,-toPlayer.z);
    } else if(this.timer<=0){
      this.timer=1.5+Math.random()*2;
      this.wanderAngle=Math.random()*Math.PI*2;
    }
    if(dist>=27 && this.wanderAngle!==undefined){
      this.position.x+=Math.sin(this.wanderAngle)*dt*1.1;
      this.position.z+=Math.cos(this.wanderAngle)*dt*1.1;
    }
    this.position.x=THREE.MathUtils.clamp(this.position.x,-83,83);
    this.position.z=THREE.MathUtils.clamp(this.position.z,-83,83);
    this.group.position.copy(this.position);
  }
}
