const STORAGE_KEY = 'project-phantom-hud-v2';
const controlIds = ['joystick-zone', 'fire-btn', 'jump-btn', 'slide-btn', 'med-btn', 'reload-btn'];
const defaults = {
  'joystick-zone': { left: '18px', bottom: '84px', right: 'auto', top: 'auto' },
  'fire-btn': { right: '17px', bottom: '114px', left: 'auto', top: 'auto' },
  'jump-btn': { right: '100px', bottom: '180px', left: 'auto', top: 'auto' },
  'slide-btn': { right: '100px', bottom: '124px', left: 'auto', top: 'auto' },
  'med-btn': { right: '112px', bottom: '76px', left: 'auto', top: 'auto' },
  'reload-btn': { right: '12px', bottom: '18px', left: 'auto', top: 'auto' }
};

export class HUDEditor {
  constructor() {
    this.modal = document.querySelector('#hud-editor');
    this.size = document.querySelector('#hud-size');
    this.opacity = document.querySelector('#hud-opacity');
    this.selected = null;
    this.editing = false;
    this.elements = Object.fromEntries(controlIds.map(id => [id, document.getElementById(id)]));
    this.load();
    document.querySelector('#hud-edit-open').addEventListener('click', () => this.open());
    document.querySelector('#hud-editor-done').addEventListener('click', () => this.close());
    document.querySelector('#hud-reset').addEventListener('click', () => this.reset());
    this.size.addEventListener('input', () => this.applySettings());
    this.opacity.addEventListener('input', () => this.applySettings());
    for (const [id, el] of Object.entries(this.elements)) this.makeDraggable(id, el);
  }
  open() {
    this.editing = true;
    this.modal.classList.remove('hidden');
    document.querySelector('#pause-btn').classList.add('hidden');
    for (const el of Object.values(this.elements)) el.classList.add('hud-editable');
    this.selected = 'fire-btn';
    this.select(this.selected);
  }
  close() {
    this.editing = false;
    this.modal.classList.add('hidden');
    document.querySelector('#pause-btn').classList.remove('hidden');
    for (const el of Object.values(this.elements)) el.classList.remove('hud-editable', 'hud-selected');
    this.save();
  }
  select(id) {
    this.selected = id;
    for (const [key, el] of Object.entries(this.elements)) el.classList.toggle('hud-selected', key === id);
    const el = this.elements[id];
    const scale = Number(el.dataset.hudScale || 100);
    const opacity = Number(el.dataset.hudOpacity || 90);
    this.size.value = scale; this.opacity.value = opacity;
    document.querySelector('#hud-size-value').textContent = `${scale}%`;
    document.querySelector('#hud-opacity-value').textContent = `${opacity}%`;
  }
  applySettings() {
    if (!this.selected) return;
    const el = this.elements[this.selected];
    const scale = Number(this.size.value), opacity = Number(this.opacity.value);
    el.dataset.hudScale = scale; el.dataset.hudOpacity = opacity;
    el.style.setProperty('--hud-scale', scale / 100);
    el.style.setProperty('--hud-opacity', opacity / 100);
    document.querySelector('#hud-size-value').textContent = `${scale}%`;
    document.querySelector('#hud-opacity-value').textContent = `${opacity}%`;
    this.save();
  }
  makeDraggable(id, el) {
    let pointer = null, startX = 0, startY = 0, originX = 0, originY = 0;
    el.addEventListener('pointerdown', e => {
      if (!this.editing) return;
      e.preventDefault(); e.stopPropagation(); this.select(id);
      pointer = e.pointerId; startX = e.clientX; startY = e.clientY;
      const r = el.getBoundingClientRect(); originX = r.left + r.width/2; originY = r.top + r.height/2;
      el.setPointerCapture?.(pointer);
    });
    el.addEventListener('pointermove', e => {
      if (!this.editing || pointer !== e.pointerId) return;
      e.preventDefault();
      const x = Math.max(4, Math.min(innerWidth - 4, originX + e.clientX - startX));
      const y = Math.max(4, Math.min(innerHeight - 4, originY + e.clientY - startY));
      el.style.left = `${x / innerWidth * 100}%`; el.style.top = `${y / innerHeight * 100}%`;
      el.style.right = 'auto'; el.style.bottom = 'auto';
      this.save();
    });
    const end = e => { if (pointer === e.pointerId) { pointer = null; this.save(); } };
    el.addEventListener('pointerup', end); el.addEventListener('pointercancel', end);
  }
  reset() {
    for (const [id, el] of Object.entries(this.elements)) {
      const d = defaults[id];
      el.style.left = d.left; el.style.right = d.right; el.style.top = d.top; el.style.bottom = d.bottom;
      el.dataset.hudScale = '100'; el.dataset.hudOpacity = '90';
      el.style.setProperty('--hud-scale', 1); el.style.setProperty('--hud-opacity', .9);
    }
    this.select('fire-btn'); this.save();
  }
  save() {
    const data = {};
    for (const [id, el] of Object.entries(this.elements)) {
      data[id] = { left: el.style.left, right: el.style.right, top: el.style.top, bottom: el.style.bottom,
        scale: Number(el.dataset.hudScale || 100), opacity: Number(el.dataset.hudOpacity || 90) };
    }
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(data)); } catch (_) {}
  }
  load() {
    let data = null;
    try { data = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null'); } catch (_) {}
    for (const [id, el] of Object.entries(this.elements)) {
      const d = data?.[id];
      const layout = d || defaults[id];
      for (const prop of ['left','right','top','bottom']) if (layout[prop] !== undefined) el.style[prop] = layout[prop];
      const scale = d?.scale || 100, opacity = d?.opacity || 90;
      el.dataset.hudScale = scale; el.dataset.hudOpacity = opacity;
      el.style.setProperty('--hud-scale', scale / 100); el.style.setProperty('--hud-opacity', opacity / 100);
    }
  }
}
