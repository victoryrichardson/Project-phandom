import * as THREE from 'three';

export function createWorld(scene) {
  const hemi = new THREE.HemisphereLight(0xd8f5ff, 0x435d45, 2.0);
  scene.add(hemi);
  const sun = new THREE.DirectionalLight(0xffedca, 2.1);
  sun.position.set(-25, 45, 20); scene.add(sun);

  const groundMat = new THREE.MeshStandardMaterial({ color: 0x63875a, roughness: 1 });
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(240,240), groundMat);
  ground.rotation.x = -Math.PI/2; ground.position.y = -0.08; ground.name='ground'; scene.add(ground);

  const pathMat = new THREE.MeshStandardMaterial({ color:0x9a9a77, roughness:1 });
  const path = new THREE.Mesh(new THREE.PlaneGeometry(13,145),pathMat);
  path.rotation.x=-Math.PI/2; path.position.set(0,0,-5); scene.add(path);

  const water = new THREE.Mesh(new THREE.PlaneGeometry(240,240),new THREE.MeshStandardMaterial({color:0x397f92, roughness:.3}));
  water.rotation.x=-Math.PI/2; water.position.y=-1.1; water.scale.set(1.1,1.1,1.1); scene.add(water);
  // Keep the island floor above the decorative water plane.
  const island = new THREE.Mesh(new THREE.CylinderGeometry(95,100,3,48),new THREE.MeshStandardMaterial({color:0x5d8050,roughness:1}));
  island.position.y=-1.7; scene.add(island);

  const buildingMat = new THREE.MeshStandardMaterial({color:0xb9a58b,roughness:.95});
  const roofMat = new THREE.MeshStandardMaterial({color:0x354b52,roughness:.9});
  const darkMat = new THREE.MeshStandardMaterial({color:0x5a6b6b,roughness:.95});
  const boxes=[];
  const positions=[[-18,-15,8,7],[18,-22,9,8],[-24,9,7,10],[24,8,10,7],[-8,-37,12,8],[30,-42,8,8],[0,22,11,9],[-35,-34,9,7]];
  positions.forEach(([x,z,w,d],i)=>{
    const h=4+(i%3)*.7;
    const body=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),buildingMat);
    body.position.set(x,h/2,z); scene.add(body); boxes.push({x,z,w,d,h});
    const roof=new THREE.Mesh(new THREE.BoxGeometry(w+.4,.45,d+.4),roofMat);
    roof.position.set(x,h+.2,z); scene.add(roof);
    const door=new THREE.Mesh(new THREE.BoxGeometry(1.2,2,.08),darkMat);
    door.position.set(x,h/2-1.0,z+d/2+.05); scene.add(door);
    for(let win=0;win<2;win++){
      const windowMesh=new THREE.Mesh(new THREE.BoxGeometry(1.25,1,.08),new THREE.MeshStandardMaterial({color:0x73b5c2,emissive:0x10282c,roughness:.3}));
      windowMesh.position.set(x+(win?1:-1)*(w*.27),h*.62,z+d/2+.06); scene.add(windowMesh);
    }
  });

  const trunkMat=new THREE.MeshStandardMaterial({color:0x5b4030});
  const leafMats=[0x2e634b,0x3e7954,0x477d57].map(c=>new THREE.MeshStandardMaterial({color:c,roughness:1}));
  for(let i=0;i<72;i++){
    const a=i*2.399, r=32+(i%7)*7;
    const x=Math.cos(a)*r, z=Math.sin(a)*r-8;
    if(boxes.some(b=>Math.abs(x-b.x)<b.w/2+2 && Math.abs(z-b.z)<b.d/2+2)) continue;
    const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.25,.42,2.8,5),trunkMat);
    trunk.position.set(x,1.35,z); scene.add(trunk);
    const crown=new THREE.Mesh(new THREE.ConeGeometry(1.8+(i%3)*.3,4.3,6),leafMats[i%leafMats.length]);
    crown.position.set(x,4.1,z); scene.add(crown);
  }
  // Low rocks as visual landmarks.
  const rockMat=new THREE.MeshStandardMaterial({color:0x78817a,roughness:1});
  for(let i=0;i<25;i++){
    const rock=new THREE.Mesh(new THREE.DodecahedronGeometry(.8+(i%4)*.25,0),rockMat);
    const a=i*2.4, r=45+(i%5)*5;
    rock.position.set(Math.cos(a)*r,.3,Math.sin(a)*r-8);
    rock.scale.y=.65; scene.add(rock);
  }
  return {boxes};
}
