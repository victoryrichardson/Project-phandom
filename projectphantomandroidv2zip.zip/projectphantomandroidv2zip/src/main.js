import * as THREE from 'three';
import { createWorld } from './world.js';
import { Player } from './player.js';
import { Bot } from './bot.js';
import { HUD } from './ui.js';
import { HUDEditor } from './hud-editor.js';

const canvas = document.querySelector('#game-canvas');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: false, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = false;
renderer.outputColorSpace = THREE.SRGBColorSpace;

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x91c8d0);
scene.fog = new THREE.Fog(0x91c8d0, 55, 180);
const camera = new THREE.PerspectiveCamera(65, window.innerWidth / window.innerHeight, 0.1, 300);

const world = createWorld(scene);
const player = new Player(scene);
const bots = [];
for (let i = 0; i < 5; i++) bots.push(new Bot(scene, new THREE.Vector3((i % 3 - 1) * 12 + 5, 0, -18 - Math.floor(i / 3) * 18), i));
const hud = new HUD();
const hudEditor = new HUDEditor();
const raycaster = new THREE.Raycaster();
const clock = new THREE.Clock();
const keys = { forward:0, side:0, fire:false };
let paused = false, ended = false, timeAlive = 0, zoneRadius = 62, ammo = 30, reserveAmmo = 90, reloadTimer = 0, fireCooldown = 0, playerShield = 25;
let messageTimer = 0;
const pickups = [];
const pickupMat = new THREE.MeshStandardMaterial({ color: 0xbff36a, emissive: 0x385c12, roughness: .5 });
for (let i = 0; i < 12; i++) {
  const mesh = new THREE.Mesh(new THREE.OctahedronGeometry(.65), pickupMat);
  const angle = i * Math.PI * 2 / 12;
  mesh.position.set(Math.cos(angle) * (9 + (i % 3) * 7), 1.1, Math.sin(angle) * (9 + (i % 3) * 7) - 7);
  scene.add(mesh); pickups.push({ mesh, kind: i % 3 === 0 ? 'med' : 'ammo', used:false });
}

function showMessage(text, duration=2.2) { hud.message(text); messageTimer = duration; }
function shoot() {
  if (paused || ended || fireCooldown > 0 || reloadTimer > 0) return;
  if (ammo <= 0) { showMessage('Magazine empty — tap RELOAD'); return; }
  ammo--; fireCooldown = .19; hud.ammo(ammo, reserveAmmo);
  // Ray from screen centre; targets are tested against the camera aim direction.
  raycaster.setFromCamera(new THREE.Vector2(0, 0), camera);
  const targets = bots.filter(b => b.alive).map(b => b.mesh);
  const hits = raycaster.intersectObjects(targets, true);
  if (hits.length) {
    let obj = hits[0].object;
    while (obj && !obj.userData.bot) obj = obj.parent;
    const bot = obj?.userData.bot;
    if (bot && bot.alive) {
      bot.takeDamage(34);
      showMessage(bot.alive ? 'HIT CONFIRMED' : 'OPPONENT ELIMINATED', 1.1);
      if (!bot.alive) hud.alive(1 + bots.filter(b => b.alive).length);
    } else showMessage('SHOT FIRED', .5);
  } else showMessage('SHOT FIRED', .5);
}
function reload() {
  if (paused || ended || reloadTimer > 0 || ammo >= 30 || reserveAmmo <= 0) return;
  reloadTimer = 1.2; showMessage('RELOADING…', 1.2);
}
function restart() { location.reload(); }
function togglePause() {
  if (ended) return;
  paused = !paused;
  document.querySelector('#center-overlay').classList.toggle('hidden', !paused);
  document.querySelector('#overlay-title').textContent = 'PAUSED';
  document.querySelector('#overlay-copy').textContent = 'Take a breath. The island can wait.';
}
document.querySelector('#pause-btn').addEventListener('click', togglePause);
document.querySelector('#resume-btn').addEventListener('click', togglePause);
document.querySelector('#restart-btn').addEventListener('click', restart);
document.querySelector('#reload-btn').addEventListener('click', () => { if (!hudEditor.editing) reload(); });
document.querySelector('#fire-btn').addEventListener('pointerdown', e => { e.preventDefault(); if (hudEditor.editing) return; keys.fire = true; shoot(); });
for (const ev of ['pointerup','pointercancel','pointerleave']) document.querySelector('#fire-btn').addEventListener(ev, () => keys.fire = false);
document.querySelector('#jump-btn').addEventListener('pointerdown', e => { e.preventDefault(); if (!hudEditor.editing) player.jump(); });
document.querySelector('#slide-btn').addEventListener('pointerdown', e => { e.preventDefault(); if (!hudEditor.editing) { player.slide(); showMessage('SLIDING', .6); } });
document.querySelector('#med-btn').addEventListener('pointerdown', e => {
  e.preventDefault(); if (hudEditor.editing) return;
  if (player.health < 100) { player.health = Math.min(100, player.health + 30); hud.health(player.health, playerShield); showMessage('MEDKIT USED'); }
  else showMessage('HEALTH IS ALREADY FULL');
});

const joystick = document.querySelector('#joystick-zone');
const base = document.querySelector('#joystick-base');
const knob = document.querySelector('#joystick-knob');
let joyPointer = null;
function updateJoystick(e) {
  const r = base.getBoundingClientRect();
  const cx = r.left + r.width/2, cy = r.top + r.height/2;
  const dx = e.clientX - cx, dy = e.clientY - cy;
  const max = r.width * .34, len = Math.hypot(dx,dy), scale = len > max ? max/len : 1;
  knob.style.transform = `translate(${dx*scale}px, ${dy*scale}px)`;
  keys.side = (dx*scale)/max;
  keys.forward = -(dy*scale)/max;
}
joystick.addEventListener('pointerdown', e => { e.preventDefault(); joyPointer = e.pointerId; joystick.setPointerCapture(e.pointerId); updateJoystick(e); });
joystick.addEventListener('pointermove', e => { if (e.pointerId === joyPointer) updateJoystick(e); });
function releaseJoy(e) { if (e.pointerId === joyPointer) { joyPointer = null; keys.forward = 0; keys.side = 0; knob.style.transform = 'translate(0,0)'; } }
joystick.addEventListener('pointerup', releaseJoy); joystick.addEventListener('pointercancel', releaseJoy);

let lookPointer = null, lastX = 0, lastY = 0;
canvas.addEventListener('pointerdown', e => {
  if (e.clientX < window.innerWidth * .38 || e.target.closest('button')) return;
  lookPointer = e.pointerId; lastX = e.clientX; lastY = e.clientY;
  canvas.setPointerCapture?.(e.pointerId);
});
canvas.addEventListener('pointermove', e => {
  if (e.pointerId !== lookPointer || paused || ended) return;
  const dx = e.clientX-lastX, dy = e.clientY-lastY;
  lastX = e.clientX; lastY = e.clientY;
  player.rotateCamera(dx * .006, dy * .004);
});
function releaseLook(e) { if (e.pointerId === lookPointer) lookPointer = null; }
canvas.addEventListener('pointerup', releaseLook); canvas.addEventListener('pointercancel', releaseLook);

window.addEventListener('keydown', e => {
  if (e.code === 'KeyW' || e.code === 'ArrowUp') keys.forward = 1;
  if (e.code === 'KeyS' || e.code === 'ArrowDown') keys.forward = -1;
  if (e.code === 'KeyA' || e.code === 'ArrowLeft') keys.side = -1;
  if (e.code === 'KeyD' || e.code === 'ArrowRight') keys.side = 1;
  if (e.code === 'Space') player.jump();
  if (e.code === 'KeyR') reload();
  if (e.code === 'Escape') togglePause();
});
window.addEventListener('keyup', e => {
  if (['KeyW','ArrowUp','KeyS','ArrowDown'].includes(e.code)) keys.forward = 0;
  if (['KeyA','ArrowLeft','KeyD','ArrowRight'].includes(e.code)) keys.side = 0;
  if (e.code === 'Space') player.jumpHeld = false;
});

function finishGame(won) {
  if (ended) return;
  ended = true;
  const overlay = document.querySelector('#center-overlay');
  overlay.classList.remove('hidden');
  document.querySelector('#overlay-title').textContent = won ? 'VICTORY' : 'MATCH OVER';
  document.querySelector('#overlay-copy').textContent = won ? 'You are the last survivor in the training arena.' : 'Your health reached zero. Try another drop.';
  document.querySelector('#resume-btn').classList.add('hidden');
  document.querySelector('#restart-btn').textContent = 'PLAY AGAIN';
}
function update(dt) {
  if (paused || ended || hudEditor.editing) return;
  timeAlive += dt;
  fireCooldown = Math.max(0, fireCooldown - dt);
  if (reloadTimer > 0) {
    reloadTimer -= dt;
    if (reloadTimer <= 0) { const needed = 30 - ammo; const loaded = Math.min(needed, reserveAmmo); ammo += loaded; reserveAmmo -= loaded; hud.ammo(ammo,reserveAmmo); showMessage('RELOADED'); }
  }
  if (keys.fire && fireCooldown <= 0) shoot();
  player.update(dt, keys, camera);
  player.updateCamera(camera);
  for (const bot of bots) bot.update(dt, player.position);
  for (const p of pickups) {
    if (p.used) continue;
    p.mesh.rotation.y += dt * 1.3; p.mesh.position.y = 1.1 + Math.sin(timeAlive*2 + p.mesh.position.x)*.15;
    if (p.mesh.position.distanceTo(player.position) < 2.2) {
      p.used = true; scene.remove(p.mesh);
      if (p.kind === 'med') { player.health = Math.min(100, player.health+25); showMessage('HEALTH PICKUP +25'); }
      else { reserveAmmo += 18; showMessage('AMMO PICKUP +18'); }
      hud.health(player.health,playerShield); hud.ammo(ammo,reserveAmmo);
    }
  }
  zoneRadius = Math.max(15, 62 - timeAlive * .45);
  const distanceFromCenter = Math.hypot(player.position.x, player.position.z);
  if (distanceFromCenter > zoneRadius) {
    player.health = Math.max(0, player.health - dt * 5);
    hud.zone('OUTSIDE ZONE');
    if (Math.floor(timeAlive*2)%2===0) hud.message('RETURN TO THE SAFE ZONE');
  } else hud.zone(`SHRINKING • ${Math.ceil(zoneRadius)}m`);
  if (Math.floor(timeAlive) % 5 === 0) hud.health(player.health,playerShield);
  if (messageTimer > 0) messageTimer -= dt;
  hud.alive(1 + bots.filter(b => b.alive).length);
  if (player.health <= 0) finishGame(false);
  if (bots.every(b => !b.alive)) finishGame(true);
}

function animate() {
  requestAnimationFrame(animate);
  const dt = Math.min(clock.getDelta(), .04);
  update(dt);
  renderer.render(scene,camera);
}
function resize() {
  camera.aspect = window.innerWidth/window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth,window.innerHeight);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1,1.5));
}
window.addEventListener('resize',resize);
hud.ammo(ammo,reserveAmmo); hud.health(player.health,playerShield); hud.alive(1+bots.length);
document.querySelector('#loading').classList.add('hidden');
showMessage('Training arena ready. Find the bots!', 3);
animate();
