# PROJECT PHANTOM — Android Browser Prototype v2

A lightweight, original third-person survival/battle-royale prototype built with Three.js. This version improves the tactical character model and adds an adjustable mobile HUD with drag positioning, button-size and transparency sliders, saved layout, reset layout, and a slide movement button.

## Run it on your Android phone

1. Download and extract the ZIP.
2. In Chrome, open **https://replit.com** and create a web/static HTML project (or use another static web host that supports ES modules).
3. Upload the files and preserve the exact folder structure:
   - `index.html`
   - `styles/main.css`
   - `src/main.js`
   - `src/world.js`
   - `src/player.js`
   - `src/bot.js`
   - `src/ui.js`
   - `src/hud-editor.js`
4. Start the preview and open it in a browser tab. Internet access is required because Three.js is loaded from jsDelivr.
5. Rotate your phone to landscape. Move with the left joystick; drag the right side to look; use FIRE, JUMP, SLIDE, MED and RELOAD.
6. Tap **HUD EDIT**. Tap a control to select it, drag it to reposition it, and use the sliders to resize or change transparency. Tap **SAVE & DONE**. Use **RESET LAYOUT** to restore the defaults.

## What is implemented

- Procedural 3D island arena, simple buildings, trees and rocks
- More detailed stylized tactical player character and rifle silhouette
- Third-person camera, mobile movement/look, jumping and short slide
- Shooting, ammo/reload, basic bots, health/ammo pickups and shrinking safe zone
- Customizable HUD positions, size and transparency; saved in local browser storage where supported

## Honest limitations

- This is still an early prototype, not a Free Fire replacement.
- The code has not been verified on your particular Android device. If the browser shows an error, send a screenshot or copy the error and we can debug it.
- The bots are local practice targets and do not yet provide full enemy combat. Collision with buildings, advanced animation, sound, matchmaking and online multiplayer are not implemented.
- Real online multiplayer will require a backend game server, networking, player synchronization, security/anti-cheat measures, and hosting. This prototype is structured as a starting point, not a finished multiplayer game.
- Graphics are procedural low-poly geometry to keep loading and rendering manageable on phones. The project uses no Free Fire assets; it is an original prototype.
